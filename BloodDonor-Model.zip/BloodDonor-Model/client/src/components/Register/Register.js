import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
  Row,
  Col,
  Card,
  Form,
  Button
} from "react-bootstrap";
 

export default function Register(props) {
  const [register, setRegister] = useState([])
  const [item, setItem] = useState([])


  useEffect(() => {
    if (item.length !== 0) {
      axios.post('http://localhost:5000/users/register', register)
        .then(response => {
          alert('Registered')
          props.history.push(`/login`)
        }).catch(err => {
          alert('user already exist')
        })
    }
  }, [item])

  return (
    <React.Fragment>
       <div className="sidenav">
  <a href="#about"><i class="fa fa-caret-right"></i>About us</a>
  <a href="#services"><i class="fa fa-caret-right"></i>Vision & Mission</a>
  <a href="#clients"><i class="fa fa-caret-right"></i>Profile</a>
 
  
</div>
      <Card className="logincard">
        <h6>About Blood Donar's Register</h6><br></br>
        <Form>
          <Form.Group controlId="formBasicEmail">
            <Form.Label>Full Name:</Form.Label>
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="text" placeholder="" name="first_name" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} min="5" />
          </Form.Group>

          <Form.Group controlId="formBasicEmail">
            <Form.Label>Phone Number</Form.Label>
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="number" placeholder="" name="phone" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} />
          </Form.Group>

          <Form.Group controlId="formBasicEmail">
            <Form.Label>Email Address</Form.Label>
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="email" placeholder="" name="email" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} />
          </Form.Group>

          <Form.Group controlId="formBasicPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="password" name="password" placeholder="" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} />
          </Form.Group>

          <Form.Group controlId="formBasicPassword">
            <Form.Label>ConfirmPassword</Form.Label>
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="password" name="password" placeholder="" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} />
          </Form.Group>

          <Form.Group controlId="formBasicEmail">
            <Form.Label>Select Country</Form.Label>
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="dropdown" name="Select Country" placeholder="" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} />
          </Form.Group>

          <Form.Group controlId="formBasicstate">
            <Form.Label>Select State</Form.Label> 
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="dropdown" name="Select State" placeholder="" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} />
          </Form.Group>
         

          <Form.Group controlId="formBasiccountry">
            <Form.Label>Select District</Form.Label>
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="dropdown" name="Select District" placeholder="" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} />
          </Form.Group>

          <Form.Group controlId="formBasiccity">
            <Form.Label>Select City</Form.Label>
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="dropdown" name="Select City" placeholder="" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} />
          </Form.Group>

          <Form.Group controlId="formBasictext">
            <Form.Label>Please Confirm Your</Form.Label><br></br>
            <Form.Label>Your</Form.Label><br></br>
            <Form.Label>Availability to </Form.Label><br></br>
            <Form.Label>donate blood</Form.Label><br></br>
            <Form.Control style={{marginLeft:"130px",marginTop:"-40px"}} type="dropdown" name="Select City" placeholder="" onChange={(e) => { setRegister({ ...register, [e.target.name]: e.target.value }) }} />
          </Form.Group>
          <br></br>
          <Form.Group controlId="formBasicCheckbox">
            <Form.Check type="checkbox" label="Check me out" />
          </Form.Group>
          <Row>
            <Col>
              <Button variant="outline-primary" onClick={() => { setItem({ hi: "hi" }) }}>
                Submit
                  </Button>
            </Col>
            <Col></Col><Col></Col>
            <Col>
              <Button variant="outline-danger" type="button" href="/">
                Cancel
                  </Button>
            </Col>
          </Row>
        </Form>
        <br></br>
        <h6>Already have a account? <span><a className="usechange" href="/login">Login</a></span></h6>
      </Card>
    </React.Fragment>
  )
}
